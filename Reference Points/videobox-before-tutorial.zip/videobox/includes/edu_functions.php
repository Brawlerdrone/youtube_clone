<?php
// Educate Functions File

function edu_title($page_title) {
	return $page_title;	
}
?>