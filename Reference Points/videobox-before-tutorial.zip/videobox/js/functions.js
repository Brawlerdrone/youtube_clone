// Site Javascript Functions

function swap_menu(sheet){
	document.getElementById('edu_menu').setAttribute('href', sheet);
}